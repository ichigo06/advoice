<section class="container__section container_start" id="archieve">
    <div class="container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-12 text-end content__relative">
                    <h1 class="title__great wow animate__animated animate__zoomOut animate__delay-1s">Achieve <br> ments</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-12 mt-3">
                    <div class="cardAchievements">
                        <div class="d-block">
                            <h5 class="cardAchievements__title percentage" data-target="40"></h5>
                            <p class="cardAchievements__paragraph">CLIENTES <br> SATISFECHOS</p>
                            <div class="cardAchievements__more"><img src="<?php echo get_stylesheet_directory_uri()?>/assets/img/cruz.png" alt=""></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12 mt-3">

                </div>
                <div class="col-md-4 col-12 mt-3">

                </div>
                <div class="col-md-4 col-12 mt-3">
                    <div class="cardAchievements">
                        <div class="d-block">
                            <h5 class="cardAchievements__title percentage" data-target="10"></h5>
                            <p class="cardAchievements__paragraph">CLIENTES <br> SATISFECHOS</p>
                            <div class="cardAchievements__more"><img src="<?php echo get_stylesheet_directory_uri()?>/assets/img/cruz.png" alt=""></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12 mt-3">
                    <div class="cardAchievements">
                        <div class="d-block">
                            <h5 class="cardAchievements__title porcent percentage" data-target="20"></h5>
                            <p class="cardAchievements__paragraph">CLIENTES <br> SATISFECHOS</p>
                            <div class="cardAchievements__more"><img src="<?php echo get_stylesheet_directory_uri()?>/assets/img/cruz.png" alt=""></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12 mt-3">
                    <div class="cardAchievements">
                        <div class="d-block">
                            <h5 class="cardAchievements__title porcent percentage" data-target="30"></h5>
                            <p class="cardAchievements__paragraph">CLIENTES <br> SATISFECHOS</p>
                            <div class="cardAchievements__more"><img src="<?php echo get_stylesheet_directory_uri()?>/assets/img/cruz.png" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </dv>    
</section>