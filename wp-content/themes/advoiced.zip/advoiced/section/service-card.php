<section class="container__section container_start">
    <div class="container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div>
                        <h1 class="title__great">Servicios</h1>
                    </div>
                    <div class="row">
                        <div class="col-12  wow animate__animated animate__fadeInLeft animate__delay-1s">
                            <div class="swiper2 card-service-slider">
                                <div class="swiper-wrapper">
                                    <!-- <div class="prev-service"></div> -->
                                    <div class="cardService swiper-slide">
                                        <div class="cardService__content">
                                            <h5 class="cardService__content__title">IDENTIDAD DE MARCA (BRANDING)</h5>
                                            <p class="cardService__content__paragraph">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat </p>
                                        </div>
                                        <div class="cardService__img">
                                            <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/img/service.png" alt="" width="100%">
                                        </div>
                                    </div>
                                    <div class="cardService swiper-slide">
                                        <div class="cardService__content">
                                            <h5 class="cardService__content__title">IDENTIDAD DE MARCA (BRANDING)</h5>
                                            <p class="cardService__content__paragraph">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat </p>
                                        </div>
                                        <div class="cardService__img">
                                            <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/img/service.png" alt="" width="100%">
                                        </div>
                                    </div>
                                    <div class="cardService swiper-slide">
                                        <div class="cardService__content">
                                            <h5 class="cardService__content__title">IDENTIDAD DE MARCA (BRANDING)</h5>
                                            <p class="cardService__content__paragraph">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat </p>
                                        </div>
                                        <div class="cardService__img">
                                            <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/img/service.png" alt="" width="100%">
                                        </div>
                                    </div>
                                    <div class="cardService swiper-slide">
                                        <div class="cardService__content">
                                            <h5 class="cardService__content__title">IDENTIDAD DE MARCA (BRANDING)</h5>
                                            <p class="cardService__content__paragraph">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat </p>
                                        </div>
                                        <div class="cardService__img">
                                            <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/img/service.png" alt="" width="100%">
                                        </div>
                                    </div>
                                    <div class="cardService swiper-slide">
                                        <div class="cardService__content">
                                            <h5 class="cardService__content__title">IDENTIDAD DE MARCA (BRANDING)</h5>
                                            <p class="cardService__content__paragraph">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat </p>
                                        </div>
                                        <div class="cardService__img">
                                            <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/img/service.png" alt="" width="100%">
                                        </div>
                                    </div>
                                    <!-- <div class="next-service"></div> -->
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>